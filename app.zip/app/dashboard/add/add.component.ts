import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/employee';
import * as alertify from 'alertifyjs';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  employees!:Employee[];

  constructor(private httpClient:HttpClient) { }

  ngOnInit(): void {
  }
  onSubmit(data:Employee)
  {
    this.httpClient.post('http://localhost:8091/emp/empAdd',data).subscribe((result)=>{
      console.warn("result",result);
      console.warn(data);
      alertify.alert('Success!!', 'Form is successfully submitted');
    })
  }

}
