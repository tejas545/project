import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/employee';
import * as alertify from 'alertifyjs';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  emp_id!:string;

  constructor(private httpClient:HttpClient) { }

  ngOnInit(): void {
  }
  onSubmit(data:Employee){
    this.httpClient.post('http://localhost:8091/emp/empUpdate/'+`${data.emp_id}`,data).subscribe((result)=>{
      console.warn("result",this.emp_id);
      console.warn(data);
      alertify.alert('Success!!', 'Form is successfully Updated');
    })
  }

}
